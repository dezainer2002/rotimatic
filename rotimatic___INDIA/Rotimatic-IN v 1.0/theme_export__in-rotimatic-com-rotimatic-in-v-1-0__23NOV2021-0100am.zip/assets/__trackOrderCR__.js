// staging / prod
const ___env___         =   `prod`;
const ___oDetail___     =   `https://60aqpll7ak.execute-api.us-east-1.amazonaws.com/${ ___env___ }/pull-latest-order`;

const ___headers___     =   {
  'Content-Type'                :   'application/json',
  'x-api-key'                   :   'JwoRNqsOLG5D2djeGip5E7bEpEgcQg0w9olkf5n8'
};

// const ___aShip___       =   `https://rotimaticus.aftership.com/api/v2/shipments?lang=en&username=rotimaticus&`;
const ___aShip___       =   `https://api.aftership.com/v4/trackings?page=1&limit=100&`;
const ___aShipApKey___  =   `8f92edcf-ad20-45a7-b752-c853f9f2eee1`;
const ___searchImg___   =   `/search?view=getImgBy_SKU&type=product`;
const ___orderObj___    =   `__orderObj__`;

const ___msgs___        =   {
  enterValidOrderNumber         :     `Enter valid order number`,
  enterValidEmail               :     `Enter valid email address`,
  estimatedShippingDates        :     `Tracking data will be appear soon`,
  estimateWillAppearSoon        :     `estimate will be appear soon, please try again later`,
  shippingProfileName           :     `Shipping timeline is`,
  by                            :     `by `,
  to                            :     ` to `,
  dash                          :     ` - `,
  ASAP                          :     `ASAP`,
  trackingNumberErr             :     `No record found against given tracking number, please check tracking number or contact at support@rotimatic.com`
};
